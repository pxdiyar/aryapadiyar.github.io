#
# Generated Makefile - do not edit!
#
#
# This file contains information about the location of compilers and other tools.
# If you commmit this file into your revision control server, you will be able to 
# to checkout the project and build it from the command line with make. However,
# if more than one person works on the same project, then this file might show
# conflicts since different users are bound to have compilers in different places.
# In that case you might choose to not commit this file and let MPLAB X recreate this file
# for each user. The disadvantage of not commiting this file is that you must run MPLAB X at
# least once so the file gets created and the project can be built. Finally, you can also
# avoid using this file at all if you are only building from the command line with make.
# You can invoke make with the values of the macros:
# $ makeMP_CC="/opt/microchip/mplabc30/v3.30c/bin/pic30-gcc" ...  
#
PATH_TO_IDE_BIN=/Applications/MPLAB X IDE v6.35.app/Contents/Resources/mplab_ide/platform/../mplab_ide/modules/../../bin/
# Adding MPLAB X bin directory to path.
PATH:=/Applications/MPLAB X IDE v6.35.app/Contents/Resources/mplab_ide/platform/../mplab_ide/modules/../../bin/:$(PATH)
# Path to java used to run MPLAB X when this makefile was created
MP_JAVA_PATH="/Applications/sys/java/zulu8.86.0.25-ca-fx-jre8.0.452-macosx_aarch64/zulu-8.jre/Contents/Home/bin/"
OS_CURRENT="$(shell uname -s)"
MP_CC="/Applications/microchip/xc8/v3.10/bin/xc8-cc"
# MP_CPPC is not defined
# MP_BC is not defined
MP_AS="/Applications/microchip/xc8/v3.10/bin/xc8-cc"
MP_LD="/Applications/microchip/xc8/v3.10/bin/xc8-cc"
MP_AR="/Applications/microchip/xc8/v3.10/bin/xc8-ar"
DEP_GEN=${MP_JAVA_PATH}java -jar "/Applications/MPLAB X IDE v6.35.app/Contents/Resources/mplab_ide/platform/../mplab_ide/modules/../../bin/extractobjectdependencies.jar"
MP_CC_DIR="/Applications/microchip/xc8/v3.10/bin"
# MP_CPPC_DIR is not defined
# MP_BC_DIR is not defined
MP_AS_DIR="/Applications/microchip/xc8/v3.10/bin"
MP_LD_DIR="/Applications/microchip/xc8/v3.10/bin"
MP_AR_DIR="/Applications/microchip/xc8/v3.10/bin"
DFP_DIR=/Applications/packs/Microchip/PIC18F-Q_DFP/1.30.487
